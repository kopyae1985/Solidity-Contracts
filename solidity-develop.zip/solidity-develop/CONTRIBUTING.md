# Contribution Guidelines

Please see our contribution guidelines in [the Solidity documentation](https://docs.soliditylang.org/en/latest/contributing.html).

Thank you for your help!
