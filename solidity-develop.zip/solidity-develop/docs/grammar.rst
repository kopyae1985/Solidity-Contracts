****************
Language Grammar
****************

.. a4:autogrammar:: SolidityParser
   :only-reachable-from: SolidityParser.sourceUnit
   :undocumented:
   :cc-to-dash:

.. a4:autogrammar:: SolidityLexer
   :only-reachable-from: SolidityParser.sourceUnit
   :fragments:
   :cc-to-dash: